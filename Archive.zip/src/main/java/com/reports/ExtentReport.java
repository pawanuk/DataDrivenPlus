package com.reports;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.utils.ReadPropertyFile;

public class ExtentReport {

	public static ExtentReports report=null;
	public static ExtentTest loggertest=null;
	public static String extentreportpath="";
	

	//To avoid external initialization
	private ExtentReport() {
		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy_ hh_mm_ss");
		Date date = new Date();
		String currentDate = formatter.format(date);
		if(ReadPropertyFile.get("OverrideResults").equalsIgnoreCase("yes")) 
		{
			if(ReadPropertyFile.get("ResultPath").equals("")) 
			{
				extentreportpath=".\\ExtentReports\\Test Report.html";
				
			}
			else {
				extentreportpath=ReadPropertyFile.get("ResultPath")+"\\ExtentReports\\Test Report.html";
			}
		}
		else 
		{
			if(ReadPropertyFile.get("ResultPath").equals("")) 
			{
				extentreportpath=".\\ExtentReports\\Test Report_"+currentDate+".html";
			}
			
			else
			{
				extentreportpath=ReadPropertyFile.get("ResultPath")+"\\ExtentReports\\Test Report_"+currentDate+".html";
				
			}

		}
		report=new ExtentReports(extentreportpath);
		report.loadConfig(new File("./src/test/resources/extentreport.xml"));
	}

	public static void initialize()
	{
		ExtentReport report=new ExtentReport();
	}

}
